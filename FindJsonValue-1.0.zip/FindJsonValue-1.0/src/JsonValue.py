import types


def getByMultiLevelKey(json, l_key, default):
    ret = json
    for k in l_key:
        if type(k) is types.IntType:
            if k < 0: return default
            if not (type(ret) is types.ListType): return default
            if len(ret) <= k: return default
        elif type(k) is types.StringType:
            if not (type(ret) is types.DictType):
                return default
            if not ret.has_key(k):
                return default
        else:
            return default
        ret = ret[k]

    return ret


