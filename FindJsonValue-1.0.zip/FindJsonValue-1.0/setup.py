# -*- coding: utf-8 -*-

from distutils.core import setup

setup(

    name='FindJsonValue',

    version='1.0',

    description='FindJsonValue',

    author='Duchao',

    author_email='Duchao@qiyi.com',

    url=' ',

    license='No License',

    platforms='any',

    py_modules=['JsonValue'],

    package_dir={'': 'src'},

    package_data={'': ['*.bat', '*.cfg'],},

    include_package_data=False,

)