#coding=utf-8
import simplejson
from types import StringTypes
from google.protobuf.descriptor import FieldDescriptor as FD

__all__ = ['dict_to_protobuf','protobuf_to_dict']

class ConvertException(Exception):
    pass

def parse_list(values,message):

    if isinstance(values[0],dict):
        for v in values:
            cmd = message.add()
            parse_dict(v,cmd)
    else:
        message.extend(values)


def parse_dict(values,message):
    for k,v in values.iteritems():
        if isinstance(v,dict):
            parse_dict(v,getattr(message,k))
        elif isinstance(v,list):
            parse_list(v,getattr(message,k))
        else:
            try:
                setattr(message, k, v)
            except AttributeError:
                raise Exception('try to access invalid attributes %r.%r = %r',message,k,v)


def pb2dict(obj):

    adict = {}
    if not obj.IsInitialized():
        return None
    for field in obj.DESCRIPTOR.fields:
        if not getattr(obj, field.name):
            continue
        if not field.label == FD.LABEL_REPEATED:
            if not field.type == FD.TYPE_MESSAGE:
                adict[field.name] = getattr(obj, field.name)
            else:
                value = pb2dict(getattr(obj, field.name))
                if value:
                    adict[field.name] = value
        else:
            if field.type == FD.TYPE_MESSAGE:
                adict[field.name] = \
                    [pb2dict(v) for v in getattr(obj, field.name)]
            else:
                adict[field.name] = [v for v in getattr(obj, field.name)]
    return adict


def dict_to_protobuf(value,message):
    parse_dict(value,message)


def protobuf_to_dict(obj):

    return simplejson.dumps(pb2dict(obj), sort_keys=True, indent=4)

