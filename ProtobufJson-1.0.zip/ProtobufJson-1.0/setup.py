# -*- coding: utf-8 -*-

from distutils.core import setup

setup(

    name='ProtobufJson',

    version='1.0',

    description='protobuf to Json',

    author='Duchao',

    author_email='Duchao@qiyi.com',

    url=' ',

    license='No License',

    platforms='any',

    py_modules=['protobuf_to_dict'],

    package_dir={'': 'src'},

    # packages=['protobuf_to_dict'],

    package_data={'': ['*.bat', '*.cfg'],},

    include_package_data=False,

)